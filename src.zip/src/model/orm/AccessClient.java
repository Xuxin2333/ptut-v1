package model.orm;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.data.Client;
import model.orm.exception.DataAccessException;
import model.orm.exception.DatabaseConnexionException;
import model.orm.exception.Order;
import model.orm.exception.RowNotFoundOrTooManyRowsException;
import model.orm.exception.Table;

/**
 * Classe réalisant le lien entre le programme Java et les clients de la base de
 * données Oracle
 */

public class AccessClient {
	public AccessClient() {
	}

	/**
	 * Permet de creer un client dans la base de donnée(creer un client)
	 * pfClient Client a creer
	 * 
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * @throws RowNotFoundOrTooManyRowsException
	 */

	public void creerClient(Client pfClient)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		try {
			Connection con = LogToDatabase.getConnexion();
			CallableStatement call = con.prepareCall("{call CreerClient(?,?,?,?,?)}");

			call.setString(1, pfClient.getNom());
			call.setString(2, pfClient.getPrenom());
			call.setString(3, pfClient.getEntreprise());
			call.setString(4, pfClient.getEmail());
			call.setString(5, pfClient.getTelephone());
			
			call.execute();
			int result = call.executeUpdate();
			call.close();
			
			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.Client, Order.INSERT,
						"Insert anormal (insert de moins ou plus d'une ligne)", null, result);
			}
			con.commit();

		} catch (SQLException e) {
			throw new DataAccessException(Table.Client, Order.SELECT, "Erreur accés", e);
		}
	}

	/**
	 * Permet de récuperer les clients de la base de données. dont le nom ou le
	 * prénom commencent par nomOuPrenom
	 * 
	 * @param nomOuPrenom
	 *            début du nom ou du prénom recherchés
	 * @return une ArrayList d' Client
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * @throws RowNotFoundOrTooManyRowsException
	 * 
	 */
	public ArrayList<Client> getClients(String nomOuPrenom)
			throws DataAccessException, DatabaseConnexionException, RowNotFoundOrTooManyRowsException {
		// Initialisation
		ArrayList<Client> alClient = new ArrayList<>();

		try {
			// Connexion a la base de données
			Connection con = LogToDatabase.getConnexion();

			nomOuPrenom = "%" + nomOuPrenom.toUpperCase() + "%";

			// Requete
			String query = "Select c.* " + " FROM Client c " + " WHERE (upper(c.nom) like ? OR upper(c.prenom) like ?)"
					+ " ORDER BY c.nom";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, nomOuPrenom);
			pst.setString(2, nomOuPrenom);

			//System.err.println(query);

			// Exécution de la requete
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				// On crée l'Client
				Client c = new Client(rs.getInt("idNumCli"), rs.getString("nom"), rs.getString("prenom"),
						rs.getString("entreprise"), rs.getString("email"), rs.getString("telephone").toString(),
						rs.getInt("estACtif"));
				// On ajoute l'Client a l'arrayList
				alClient.add(c);
			}

			// on ferme la requete
			rs.close();
			pst.close();
			return alClient;

		} catch (SQLException e) {
			throw new DataAccessException(Table.Client, Order.SELECT, "Erreur accés", e);
		}
	}

	/**
	 * Permet d'afficher un client dans la base de donnée(Créer un client)
	 * 
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * @throws RowNotFoundOrTooManyRowsException
	 */

	public void afficherClient(Client pfClient)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		try {
			Connection con = LogToDatabase.getConnexion();
			CallableStatement call = con.prepareCall("{call AfficherClient(?)}");

			call.setInt(1, pfClient.getId());
			call.registerOutParameter(2, java.sql.Types.VARCHAR);
			call.registerOutParameter(3, java.sql.Types.VARCHAR);
			call.registerOutParameter(4, java.sql.Types.VARCHAR);
			call.registerOutParameter(5, java.sql.Types.VARCHAR);
			call.registerOutParameter(6, java.sql.Types.VARCHAR);
			call.registerOutParameter(7, java.sql.Types.INTEGER);

			call.execute();

			String nomC = call.getString(2);
			String prenomC = call.getString(3);
			String EntrepriseC = call.getString(4);
			String emailC = call.getString(5);
			String telephoneC = call.getString(6);
			int estActifC = call.getInt(7);

			int result = call.executeUpdate();

			call.close();

			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.Client, Order.SELECT,
						"SELECT anormal (SELECT de moins ou plus d'une ligne)", null, result);
			}
			con.commit();

		} catch (SQLException e) {
			throw new DataAccessException(Table.Client, Order.Afficher, "Erreur accés", e);
		}

	}

	/**
	 * Permet de modifier un client dans la base de donnée(Modifier un client)
	 * modifier les informations d’un client
	 * 
	 * @param pfClient
	 *            Un client a insérer
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 */

	public void modifierClient(Client pfClient)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		try {
			Connection con = LogToDatabase.getConnexion();
			CallableStatement call = con.prepareCall("{call modifierClient (?,?,?,?,?,?)}");

			call.setInt(1, pfClient.getId());
			call.setString(2, pfClient.getNom());
			call.setString(3, pfClient.getPrenom());
			call.setString(4, pfClient.getEntreprise());
			call.setString(5, pfClient.getEmail());
			call.setString(6, pfClient.getTelephone());
			call.execute();

			int result = call.executeUpdate();
			call.close();

			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.Client, Order.INSERT,
						"Insert anormal (insert de moins ou plus d'une ligne)", null, result);
			}
			con.commit();

		} catch (SQLException e) {
			throw new DataAccessException(Table.Client, Order.INSERT, "Erreur accés", e);
		}

	}

	/**
	 * Permet de desactiver un client
	 * 
	 * @param pfClient
	 *            un Client en desactiverClient
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * @throws RowNotFoundOrTooManyRowsException
	 */
	public void desactiverClient(Client pfClient)
			throws DataAccessException, DatabaseConnexionException, RowNotFoundOrTooManyRowsException {
		try {
			Connection con = LogToDatabase.getConnexion();

			CallableStatement call = con.prepareCall("{call desactiverClient (?)}");

			call.setInt(1, pfClient.getId());
			call.execute();

			int result = call.executeUpdate();
			call.close();

			if (result != 1) {
				con.rollback();
				throw new RowNotFoundOrTooManyRowsException(Table.Client, Order.UPDATE,
						"Update anormal (update de moins ou plus d'une ligne)", null, result);
			}
			con.commit();

		} catch (SQLException e) {
			throw new DataAccessException(Table.Client, Order.UPDATE, "Erreur accés", e);

		}

	}

}
