
	
	package view.app;

	import model.data.*;

	import model.orm.AccessCompetence;
	import model.orm.AccessNiveau;
	import model.orm.exception.DataAccessException;
	import model.orm.exception.DatabaseConnexionException;

	import javax.swing.*;
	import javax.swing.border.Border;
	import javax.swing.border.TitledBorder;

	import java.awt.*;
	import java.util.ArrayList;

	/**
	 * Fenetre d'édition d'un client : Create Update Delete Desactiver 
	 */

	@SuppressWarnings("serial")
	public class ClientEditor extends JDialog {
		
		public enum ModeEdition {
			CREATION, MODIFICATION, VISUALISATION,DESACTIVER
			// pas de suppression car fonctionnellement impossible
		};

		
		private ModeEdition modeActuel;
		
	    // Panels
	    private JPanel contentPane;
	    private JPanel champsPanel ;
	    private JPanel boutonsPanel ;

	    // Label titre
	    private JLabel titreLabel ;

	    // Police d'écriture
	    private Font titreFont = new Font("Arial", Font.BOLD, 22) ;
	    private Font normalFont = new Font("Arial", Font.PLAIN, 16) ;

	    // Boutons
	    private JButton enregistrerBouton ;
	    private JButton annulerBouton ;

	    // Dimension
	    private Dimension dimensionBouton = new Dimension(140,35) ;
	    private Dimension dimensionLabel = new Dimension(200,40) ;
	    private Dimension dimensionText = new Dimension(135,25) ;
	    
	    // Zones de texte titres des saisies
	    private JLabel idLabel ;
	    private JLabel nomLabel ;
	    private JLabel prenomLabel ;
	    private JLabel EntrepriseLabel ;
	    private JLabel EmailLabel;
	    private JLabel TelephoneLabel;
	    private JLabel estActifLabel;


	    // Zones de saisie
	    private JTextField idText ;
	    private JTextField nomText ;
	    private JTextField prenomText ;
	    private JTextField EntrepriseText ;
	    private JTextField EmailText ;
	    private JTextField TelephoneText ;

	    
	    private JCheckBox estActifTB;


	    //Employe qui utilise l'application

     	private Employe employueUtilisateur;
		
		// Client modifié ou visualisé
		private Client clientEdite;
		
		// Client résultat (saisi ou modifié), null si annulation
		private Client clientResult;
		
		/**
		 * Ouverture de la boite de dialogue d'édition d'un employé
		 *
		 * @param owner   fenêtre  mère de la boite de dialogue
		 * @param employueUtilisateur Employ" connecté à l'application
		 * @param clientEdite  Objet de type Employé à éditer (éventuellement null en création).
		 * @param mode    Mode d'ouverture (CREATION, MODIFICATION, VISUALISATION)
		 * 
		 * @return un objet Client si l'action est validée / null sinon
		 */
		public static Client showClientEditor(Window owner, Employe employueUtilisateur, Client clientEdite, ClientEditor.ModeEdition mode) {
			if (mode == ClientEditor.ModeEdition.CREATION) {
				clientEdite = new Client();
			} //else {
				//clientEdite = new Client(clientEdite);
			//}
			
			ClientEditor dial = new ClientEditor(clientEdite, employueUtilisateur, owner, mode);
	     //  dial.clientResult = null;
			dial.setModal(true);
			dial.setVisible(true);
			// le programme appelant est bloqué jusqu'au masquage de la JDialog.
			dial.dispose();
			return dial.clientEdite;
		}

		// =======================================================================
		// Les constructeurs de la classe sont privés
		// Pour créer un éditeur, Il faut utiliser la méthode statique 
		// == > showClientEditor() 
		// =======================================================================
		private ClientEditor(Client pfclientEdite, Employe pfEmployueUtilisateur, Window owner, ClientEditor.ModeEdition pfMode) {
	        
	        super(owner);
	        this.employueUtilisateur = pfEmployueUtilisateur ;
	        this.clientEdite = pfclientEdite;
	        this.clientResult = null;
	        this.modeActuel = pfMode;


	        
	        setTitle("Gestion d'un client");
	        setSize(400, 620) ;
	        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
	        
	        // Border
	        Border blackline = BorderFactory.createLineBorder(Color.black);
	        TitledBorder title = BorderFactory.createTitledBorder(
	                blackline, "Veuillez remplir tous les champs possibles",
	                TitledBorder.CENTER,TitledBorder.DEFAULT_POSITION,
	                new Font("Arial", Font.ITALIC, 15) );

	        Border raisedbevel = BorderFactory.createRaisedBevelBorder();
	        Border loweredbevel = BorderFactory.createLoweredBevelBorder();
	        Border compound = BorderFactory.createCompoundBorder(
	                raisedbevel, loweredbevel);

	        // Toute la fenetre
	        contentPane = new JPanel(new BorderLayout()) ;
	        setContentPane(contentPane);

	        // Titre label
	        titreLabel = new JLabel("tempo");
	        titreLabel.setHorizontalAlignment(0);
	        titreLabel.setPreferredSize(new Dimension(400, 80));
	        titreLabel.setFont(titreFont);
	        titreLabel.setBorder(compound);

	        contentPane.add(titreLabel, BorderLayout.NORTH);

	        // Champs Panel
	        champsPanel = new JPanel(new FlowLayout()) ;
	        contentPane.add(champsPanel,  BorderLayout.CENTER);
	        champsPanel.setBorder(title);

	        // Boutons Panel
	        boutonsPanel = new JPanel(new FlowLayout());
	        boutonsPanel.setPreferredSize(new Dimension(150,50));
	        contentPane.add(boutonsPanel, BorderLayout.SOUTH);

	        // Boutons
	        enregistrerBouton = new JButton("Enregister");
	        enregistrerBouton.setBackground(new Color(104, 177, 255)) ;
	        enregistrerBouton.setPreferredSize(dimensionBouton);
	        enregistrerBouton.addActionListener(e -> actionOK());

	        boutonsPanel.add(enregistrerBouton);

	        annulerBouton = new JButton("Annuler");
	        annulerBouton.setBackground(new Color(104, 177, 255)) ;
	        annulerBouton.setPreferredSize(dimensionBouton);
	        annulerBouton.addActionListener(e -> actionAnnuler());
	        annulerBouton.setActionCommand("quitter");

	        boutonsPanel.add(annulerBouton,BorderLayout.SOUTH);

	        // ID
	        idLabel = new JLabel("ID") ;
	        idLabel.setHorizontalAlignment(0);
	        idLabel.setPreferredSize(dimensionLabel);
	        idLabel.setFont(normalFont);
	        champsPanel.add(idLabel);

	        idText = new JTextField("Généré automatiquement");
	        idText.setPreferredSize(dimensionText);
	        idText.setEnabled(false);
	        champsPanel.add(idText);

	        // Nom
	        nomLabel = new JLabel("Nom") ;
	        nomLabel.setHorizontalAlignment(0);
	        nomLabel.setPreferredSize(dimensionLabel);
	        nomLabel.setFont(normalFont);
	        champsPanel.add(nomLabel);
	        
	        nomText = new JTextField();
	        nomText.setPreferredSize(dimensionText);
	        champsPanel.add(nomText);

	        // Prenom
	        prenomLabel = new JLabel ("Prénom") ;
	        prenomLabel.setHorizontalAlignment(0);
	        prenomLabel.setPreferredSize(dimensionLabel);
	        prenomLabel.setFont(normalFont);
	        champsPanel.add(prenomLabel);
	        
	        prenomText = new JTextField();
	        prenomText.setPreferredSize(dimensionText);
	        champsPanel.add(prenomText);

	        // Entreprise
	        EntrepriseLabel = new JLabel("Entreprise") ;
	        EntrepriseLabel.setHorizontalAlignment(0);
	        EntrepriseLabel.setPreferredSize(dimensionLabel);
	        EntrepriseLabel.setFont(normalFont);
	        champsPanel.add(EntrepriseLabel);

	        EntrepriseText = new JTextField();
	        EntrepriseText.setPreferredSize(dimensionText);
	        champsPanel.add(EntrepriseText);

	        // Email
	        EmailLabel = new JLabel("Email") ;
	        EmailLabel.setHorizontalAlignment(0);
	        EmailLabel.setPreferredSize(dimensionLabel);
	        EmailLabel.setFont(normalFont);
	        champsPanel.add(EmailLabel);

	        EmailText = new JTextField("user@mail.server.name");
	        EmailText.setPreferredSize(dimensionText);
	        champsPanel.add(EmailText);
	        
	       
	        // Telephone
	        TelephoneLabel = new JLabel("Telephone") ;
	        TelephoneLabel .setHorizontalAlignment(0);
	        TelephoneLabel.setPreferredSize(dimensionLabel);
	        TelephoneLabel.setFont(normalFont);
	        champsPanel.add(TelephoneLabel);

	        TelephoneText = new JTextField("xx-xx-xx-xx-xx");
	        TelephoneText.setPreferredSize(dimensionText);
	        champsPanel.add(TelephoneText);

	        
	        // estActif
	        estActifLabel = new JLabel("estActif ?") ;
	        estActifLabel.setHorizontalAlignment(0);
	        estActifLabel.setPreferredSize(dimensionLabel);
	        estActifLabel.setFont(normalFont);
	        champsPanel.add(estActifLabel);

	        estActifTB = new JCheckBox();
	        estActifTB.setSelected(true);
	        champsPanel.add(estActifTB);

	        
	        
	        this.setLocationRelativeTo(this.getParent());
			
	        changeEtatSaisie ();
	    }

	    private void changeEtatSaisie() {
			switch (modeActuel) {
				case CREATION :
					idText.setEnabled(false); 
				    nomText.setEnabled(true); 
				    prenomText.setEnabled(true); 
				    EntrepriseText.setEnabled(true); 
	                EmailText.setEnabled(true); 
	                TelephoneText.setEnabled(true); 
				    estActifTB.setEnabled(true);			    
				    titreLabel.setText("Créer Client");

				    enregistrerBouton.setText("Enregister");
			        annulerBouton.setText("Annuler");
				break;

				case MODIFICATION:
					idText.setEnabled(false); 
	                nomText.setEnabled(true); 
	                prenomText.setEnabled(true); 
	                EntrepriseText.setEnabled(true); 
	                EmailText.setEnabled(true); 
	                TelephoneText.setEnabled(true); 
	                estActifTB.setEnabled(true);  
				    titreLabel.setText("Modifier Client");

				    enregistrerBouton.setText("Modifier");
			        annulerBouton.setText("Annuler");
					break;

				case VISUALISATION:
					idText.setEnabled(false); 
	                nomText.setEnabled(true); 
	                prenomText.setEnabled(true); 
	                EntrepriseText.setEnabled(true); 
	                EmailText.setEnabled(true); 
	                TelephoneText.setEnabled(true); 
	                estActifTB.setEnabled(true);  			    
				    titreLabel.setText("Voir Client");

				    enregistrerBouton.setText("");
				    enregistrerBouton.setEnabled(true);
			        annulerBouton.setText("Retour");
					break;
					
				case DESACTIVER:
					idText.setEnabled(false); 
	                nomText.setEnabled(true); 
	                prenomText.setEnabled(false); 
	                EntrepriseText.setEnabled(false); 
	                EmailText.setEnabled(false); 
	                TelephoneText.setEnabled(false); 
	                estActifTB.setEnabled(true);  			    
				    titreLabel.setText("Changer l'activité du client");

				    enregistrerBouton.setText("Changer l'activité");
				    enregistrerBouton.setEnabled(true);
			        annulerBouton.setText("Conserver l'activité");
					break;
			}
			
	        if (modeActuel != ClientEditor.ModeEdition.CREATION) {
	        	// on remplit les champs 
		        idText.setText(Integer.toString(clientEdite.getId()));
		        nomText.setText(clientEdite.getNom());
		        prenomText.setText(clientEdite.getPrenom());
	            EntrepriseText.setText(clientEdite.getEntreprise());
	            EmailText.setText(clientEdite.getEmail()); 
	            TelephoneText.setEnabled(true); 
	            estActifTB.setSelected ( (clientEdite.getEstActif() == Client.EST_ACTIF) );		      

			    
	        }
		}

	    
	    
	    /**
	     * Genere le client avec la valeurs des champs remplis
	     * @return un client
	     */
	    private Client generateClient(){
	        int estActifC;
	        estActifC = (estActifTB.isSelected() ? Client.EST_ACTIF : Client.EST_INACTIF);
	        // On récupere tous les elements pour créer l'employé
	        Client c ;
	        if (modeActuel == ClientEditor.ModeEdition.CREATION){
	            c = new Client( -1 , nomText.getText().trim() , prenomText.getText().trim() , EntrepriseText.getText().trim() ,EmailText.getText().trim(),EmailText.getText().trim(), estActifC) ;
	        }else {
	            c = new Client( Integer.parseInt(idText.getText()) , nomText.getText() , prenomText.getText() , EntrepriseText.getText(),EmailText.getText() ,EmailText.getText(), estActifC) ;
	        }

	        return c ;
	    }


	
	    private void actionOK() {
	        if (verifChamps()){
	            this.clientResult = generateClient() ;
	            this.setVisible(false);
	        }else{
	            JOptionPane.showMessageDialog(this, "Veuillez saisir tous les champs", "Erreur", JOptionPane.ERROR_MESSAGE);
	        }
	    }


	


	    /**
	     * Vérifier si tous les champs ont été saisis
	     * @return vrai ou faux
	     */
	    private boolean verifChamps() {
	        if (nomText.getText().trim().isEmpty() || prenomText.getText().trim().isEmpty() || EntrepriseText.getText().trim().isEmpty() || EmailText.getText().trim().isEmpty()||TelephoneText.getText().trim().isEmpty()) {
	            return false;
	        }
	        return true;
	    }

	    private void actionAnnuler() {
	    	this.clientResult = null;
	        this.setVisible(false);

	    }
	


}

